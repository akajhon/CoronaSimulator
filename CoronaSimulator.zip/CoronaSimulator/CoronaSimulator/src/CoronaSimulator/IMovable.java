package CoronaSimulator;

/**
 * Interface IMovable: Responsável pela movimentação das pessoas no mundo.
 * Deve obrigatoriamente ser chamada em todas as classes.
 * Será implementada nas classes PessoaDoente e PessoaSaudavel.
 * @author João Pedro Rosa Cezarino (22.120.021 - 5)
 * @version 1.0
 */

public interface IMovable {
    public void mover();
}
