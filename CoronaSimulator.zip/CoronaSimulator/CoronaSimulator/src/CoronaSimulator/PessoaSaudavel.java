package CoronaSimulator;
import java.util.Random;

/**
 * Classe PessoaSaudavel: Responsável por armazenar os métodos e construtores referentes às pessoas saudáveis e vacinadas.
 * Herda da SuperClasse Pessoa.
 * Implementa a Interface IMovable.
 * Agrega a classe Virus.
 * Compõe a classe Mundo.
 * @see vacinada
 * @see PessoaSaudavel
 * @author João Pedro Rosa Cezarino (22.120.021 - 5)
 * @version 1.0
 */

public class PessoaSaudavel extends Pessoa implements IMovable {
    public boolean vacinada = false;
    int time;
    
    public PessoaSaudavel() {
    }
    /**
     * @param vacinada Booleano que representa a presença da vacina na pessoa.
     * @param x Posição da pessoa no eixo x dentro do mundo.
     * @param y Posição da pessoa no eixo y dentro do mundo.
     * @param cor Cor da pessoa dentro do mundo.
     */
    public PessoaSaudavel(boolean vacinada, int x, int y, int cor) {
        super(x, y, cor);
        this.vacinada = vacinada;
    }
    /**
     * @param vacinada Booleano que representa a presença da vacina na pessoa.
     * @param time Variável responsável pelo tempo de contaminação da pessoa
     * saudável e vacinada.
     * @param x Posição da pessoa no eixo x dentro do mundo.
     * @param y Posição da pessoa no eixo y dentro do mundo.
     * @param cor Cor da pessoa dentro do mundo. 
     */
    public PessoaSaudavel(boolean vacinada, int time, int x, int y, int cor) {
        super(x, y, cor);
        this.vacinada = vacinada;
        this.time = time;
    }
    /**
     * @param x Posição da pessoa no eixo x dentro do mundo.
     * @param y Posição da pessoa no eixo y dentro do mundo.
     * @param cor Cor da pessoa dentro do mundo. 
     */
    public PessoaSaudavel(int x, int y, int cor) {
        super(x, y, cor);
    }
    
    public boolean isVacinada() {
        return vacinada;
    }

    public void setVacinada(boolean vacinada) {
        this.vacinada = vacinada;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }
    
    @Override
    public void mover() {
        Random random = new Random();
        int op = random.nextInt(3);
        int yd = super.getY() + 1;
        int ye = super.getY() - 1;
        int xd = super.getX() + 1;
        int xe = super.getX() - 1;

        switch (op) {
            case 0:
                super.setY(yd);
                break;
            case 1:
                super.setY(ye);
                break;
            case 2:
                super.setX(xd);
                break;
            case 3:
                super.setX(xe);
                break;
        }
    }
    
}
