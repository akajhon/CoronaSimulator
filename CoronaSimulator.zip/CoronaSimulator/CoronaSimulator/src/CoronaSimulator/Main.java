package CoronaSimulator;

/**
 * Main: Responsável por rodar o código e chamar todos os métodos.
 * @author João Pedro Rosa Cezarino (22.120.021 - 5)
 * @version 1.0
 */

public class Main {
    public static void main(String[] args) {
        Mundo world = new Mundo();
        while(true){
            world.bigBang();
            try{
                Thread.sleep(1000);
            }
            catch(Exception excecao){
                excecao.printStackTrace();
            }
        }
    }
    }
    

