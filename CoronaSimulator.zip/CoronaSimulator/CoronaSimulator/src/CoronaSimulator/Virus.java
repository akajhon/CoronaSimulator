package CoronaSimulator;

/**
 * Classe Virus: Responsável por armazenar os construtores e métodos responsáveis pelo vírus que infectará as pessoas no mundo.
 * Relação de Agregação com as classes PessoaDoente e PessoaSaudavel.
 * @see contaminatedTime 
 * @author João Pedro Rosa Cezarino (22.120.021 - 5)
 * @version 1.0
 */

public class Virus {
    private int contaminatedTime;

    public Virus() {
    }
    /**
     * @param contaminatedTime Representa o tempo de duração do covid nas
     * pessoas infectadas.
     */
    public Virus(int contaminatedTime) {
        this.contaminatedTime = contaminatedTime;
    }

    public int getContaminatedTime() {
        return contaminatedTime;
    }

    public void setContaminatedTime(int contaminatedTime) {
        this.contaminatedTime = contaminatedTime;
    }

 
   
   
}
