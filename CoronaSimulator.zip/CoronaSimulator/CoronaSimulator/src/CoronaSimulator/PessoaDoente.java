package CoronaSimulator;
import java.util.Random;

/**
 * Classe PessoaDoente: Armazena os construtores e métodos que dizem respeito às Pessoas Infectadas.
 * Herda da SuperClasse Pessoa.
 * Implementa a Interface IMovable.
 * Agrega a classe Virus.
 * Compõe a classe Mundo.
 * @author João Pedro Rosa Cezarino (22.120.021 - 5)
 * @see mover
 * @see Pessoa
 * @see Virus
 * @version 1.0
 */

public class PessoaDoente extends Pessoa implements IMovable{
    public Virus covid;
    
    public PessoaDoente() {
    }
    /**
     * @param covid Objeto vírus que infecta a PessoaDoente.
     * @param x Posição da pessoa no eixo x dentro do mundo.
     * @param y Posição da pessoa no eixo y dentro do mundo.
     * @param cor Cor da pessoa dentro do mundo.
     */
    public PessoaDoente(Virus covid, int x, int y, int cor) {
        super(x, y, cor);
        this.covid = covid;
    }

    public Virus getCovid() {
        return covid;
    }

    public void setCovid(Virus covid) {
        this.covid = covid;
    }
    @Override
    public void mover() {
        Random random = new Random();
        int op = random.nextInt(3);
        int yd = super.getY() + 1;
        int ye = super.getY() - 1;
        int xd = super.getX() + 1;
        int xe = super.getX() - 1;

        switch (op) {
            case 0:
                super.setY(yd);
                break;
            case 1:
                super.setY(ye);
                break;
            case 2:
                super.setX(xd);
                break;
            case 3:
                super.setX(xe);
                break;
        }
    }
}
