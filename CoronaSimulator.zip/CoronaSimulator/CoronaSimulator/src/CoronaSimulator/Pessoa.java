package CoronaSimulator;

/**
 * SuperClasse Pessoa: Armazena os contrutores e os métodos responsáveis por definir
 * a cor e o movimento das pessoas no mundo.
 * @author João Pedro Rosa Cezarino (22.120.021 - 5)
 * @version 1.0
 */

public abstract class Pessoa {
    private int x, y, cor;

    public Pessoa(){
    }
    /**
     * @param x Posição da pessoa no eixo x dentro do mundo.
     * @param y Posição da pessoa no eixo y dentro do mundo.
     * @param cor Cor da pessoa dentro do mundo.
     */
    public Pessoa(int x, int y, int cor) {
        this.x = x;
        this.y = y;
        this.cor = cor;
    }

    public int getX() {
        return x;
    }
    /**
     * @param x Posição da pessoa no eixo x dentro do mundo.
     */
    public void setX(int x) {
        if (x > 59){
           this.x = 0;
        }
        else if (x < 0){
           this.x = 59;
        }
        else
           this.x = x;
    }

    public int getY() {
        return y;
    }
    /**
     * @param y Posição da pessoa no eixo y dentro do mundo. 
     */
    public void setY(int y) {
        if (y > 29){
           this.y = 0;
        }
        else if (y < 0){
           this.y = 29;
        }
        else
           this.y = y;
    }

    public int getCor() {
        return cor;
    }
    /**
     * @param cor Cor da pessoa dentro do mundo. 
     */
    public void setCor(int cor) {
        this.cor = cor;
    }
}
