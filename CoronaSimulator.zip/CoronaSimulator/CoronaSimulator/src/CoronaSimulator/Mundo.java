package CoronaSimulator;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Classe Mundo: Possui uma relação de composição com as classes
 * PessoaDoente, PessoaSaudavel e Hospital.
 * @author João Pedro Rosa Cezarino (22.120.021 - 5)
 * @see Hospital
 * @see PessoaDoente
 * @see PessoaSaudavel
 * @see Virus
 */

public class Mundo {
    Random aleatorio = new Random();
    public double temp = 0;
    
    public int world[][] = {{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}, 
                          {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                          {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                          {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                          {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                          {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                          {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                          {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                          {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                          {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                          {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1}, 
                          {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                          {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                          {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                          {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                          {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                          {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                          {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                          {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                          {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                          {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1}, 
                          {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                          {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                          {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                          {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                          {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                          {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                          {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                          {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                          {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}};
    
    ArrayList<Hospital> hospitais = new ArrayList<>();
    ArrayList<PessoaDoente> infectados = new ArrayList<>();
    ArrayList<PessoaSaudavel> saudaveis = new ArrayList<>();
  
    public static String vermelho = "\033[41m \033[0m"; // Borda e Interior dos hospitais
    public static String verde = "\033[42m \033[0m"; //Pessoas Saudáveis sem vacina
    public static String amarelo = "\033[43m \033[0m"; //Pessoas Infectadas
    public static String branco = "\033[47m \033[0m"; //Hospitais
    public static String magenta = "\033[45m \033[0m"; //Pessoas Saudaveis com vacina e comvirus
    public static String ciano = "\033[46m \033[0m"; //Pessoas Saudavel com vacina e sem vírus
    
    /**
     * @param saudaveis Parâmetro que armazena o arraylist de pessoas saudáveis.
     */
    public void criaSaudavel(ArrayList<PessoaSaudavel> saudaveis, int n) {
        for (int i = 0; i < n; i++) {
            while (true) {
                int posX = aleatorio.nextInt(60);
                int posY = aleatorio.nextInt(30);
                if (world[posY][posX] == 2 || world[posY][posX] == 1 || world[posY][posX] == 0) {
                    saudaveis.add(new PessoaSaudavel(posX, posY, 5));
                    break;
                }
            }
        }
    }
    
    /**
     * @param infectados Parâmetro que armazena o arraylist de pessoas infectados.
     */
    public void criaInfectado(ArrayList<PessoaDoente> infectados, int n) {
        for (int i = 0; i < n; i++) {
            Virus covid = new Virus((int) temp);
            boolean std = true;

            while (std) {
                int posX = aleatorio.nextInt(60);
                int posY = aleatorio.nextInt(30);
                if (world[posY][posX] == 2 || world[posY][posX] == 1 || world[posY][posX] == 0) {
                    for (int v = 0; v < saudaveis.size(); v++) {
                        if ((posX == saudaveis.get(v).getX() && posY == saudaveis.get(v).getY())
                                || (posX + 1 == saudaveis.get(v).getX() && posY == saudaveis.get(v).getY())
                                || (posX - 1 == saudaveis.get(v).getX() && posY == saudaveis.get(v).getY()
                                || (posX == saudaveis.get(v).getX() && posY + 1 == saudaveis.get(v).getY())
                                || (posX == saudaveis.get(v).getX() && posY - 1 == saudaveis.get(v).getY()))) {
                            break;
                        }else if (v == saudaveis.size() - 1) {
                            infectados.add(new PessoaDoente(covid, posX, posY, 6));
                            std = false;
                        }
                    }
                }
            }
        }
    }
    
    /**
     * @param hospitais Parâmetro que armazena o arraylist de hospitais.
     * @param n Representa o número de hospitais que serão gerados no mundo.
     */
    public void criaHospital(ArrayList<Hospital> hospitais, int n) {
        for (int i = 0; i < n; i++) {
            hospitais.add(new Hospital(3));
        }
    }
    
    /**
     * @param world Parâmetro que representa a matriz mundo.
     */
    public void hospitais(int world[][]) {
        for (int i = 0; i < world.length; i++) {
            for (int v = 0; v < world[i].length; v++) {
                if ((i == 5 && v == 5) || (i == 5 && v == 50) || (i == 21 && v == 50)) {

                    for (int linhaAtual = 0; linhaAtual < 5; linhaAtual++) {
                        for (int colunaAtual = 0; colunaAtual < 5; colunaAtual++) {

                            if ((colunaAtual == 2 && (linhaAtual >= 1 && linhaAtual <= 3)) || (linhaAtual == 2 && (colunaAtual >= 1 && colunaAtual <= 3))) {
                                world[i + linhaAtual][v + colunaAtual] = hospitais.get(0).getCor() - 2;
                            } else {
                                world[i + linhaAtual][v + colunaAtual] = hospitais.get(0).getCor();
                            }
                        }
                    }
                }
            }
        }
    }
     
    /**
     * @param j Índice da PessoaSaudavel no Arraylist PessoasSaudaveis.
     * @param sadio Instância do Arraylist PessoaSaudavel, que será verificado.
     * @return std - Booleano que representa se houve transmissão do covid ou não.
     */
    public boolean verificaColisao(int j, PessoaSaudavel sadio) {
        boolean std = false;
        if (sadio.getCor() == 7 || sadio.getCor() == 8) {
            sadio.mover();
        }else{
            for (int i = 0; i < infectados.size(); i++) {
                if ((sadio.getCor() == 5 && sadio.getX() == infectados.get(i).getX() && sadio.getY() == infectados.get(i).getY())
                        || (sadio.getX() + 1 == infectados.get(i).getX() && sadio.getY() == infectados.get(i).getY())
                        || (sadio.getX() - 1 == infectados.get(i).getX() && sadio.getY() == infectados.get(i).getY())
                        || (sadio.getX() == infectados.get(i).getX() && sadio.getY() + 1 == infectados.get(i).getY())
                        || (sadio.getX() == infectados.get(i).getX() && sadio.getY() - 1 == infectados.get(i).getY())) {

                    Virus covid = new Virus((int) temp);
                    infectados.add(new PessoaDoente(covid, saudaveis.get(j).getX(), saudaveis.get(j).getY(), 6));

                    infectados.get(infectados.size() - 1).mover();
                    world[infectados.get(infectados.size() - 1).getY()][infectados.get(infectados.size() - 1).getX()] = infectados.get(infectados.size() - 1).getCor();

                    saudaveis.remove(j);
                    std = true;
                    break;
                }
            }
                if (std == false){
                    sadio.mover();
                    std = false;
                }
            }
        
            return std;
    }
    
    /**
     * @param j Índice da PessoaSaudavel no Arraylist PessoasSaudaveis.
     * @param sadio Instância do Arraylist PessoaSaudavel, que será verificado.
     * @return std - Booleano que representa se houve colisão ou não.
     */
    public boolean verificaColisaoVacinada(int j, PessoaSaudavel sadio) {
        boolean std = false;
        if (sadio.getCor() == 5 || sadio.getCor() == 8){
            sadio.mover();
        }else{
            for (int i = 0; i < infectados.size(); i++) {
                if ((sadio.getCor() == 7 && sadio.getX() == infectados.get(i).getX() && sadio.getY() == infectados.get(i).getY())
                    || (sadio.getX() + 1 == infectados.get(i).getX() && sadio.getY() == infectados.get(i).getY())
                    || (sadio.getX() - 1 == infectados.get(i).getX() && sadio.getY() == infectados.get(i).getY())
                    || (sadio.getX() == infectados.get(i).getX() && sadio.getY() + 1 == infectados.get(i).getY())
                    || (sadio.getX() == infectados.get(i).getX() && sadio.getY() - 1 == infectados.get(i).getY())){
                    
                    saudaveis.add(new PessoaSaudavel(true, (int) temp, saudaveis.get(j).getX(), saudaveis.get(j).getY(), 8));

                    saudaveis.get(saudaveis.size() - 1).mover();
                    world[saudaveis.get(saudaveis.size() - 1).getY()][saudaveis.get(saudaveis.size() - 1).getX()] = saudaveis.get(saudaveis.size() - 1).getCor();
                    saudaveis.remove(j);
                    std = true;
                    break;
                }
        }
        if (std == false) {
            sadio.mover();
            std = false;
        }
        }
        return std;
    }
    
    /**
     * @param contador Representa o índice da Pessoa Infectada no ArrayList PessoaDoente.
     * @param infectado Instância do Arraylist PessoaDoente, o qual será verificado.
     * @param mapcomp Mapa usado para comparação e checagem da colisão com o
     * Hospital.
     * @return vacina - Booleano que retorna se houve cura ou não.
     */
    public boolean verificaColisaoHospital(int contador, PessoaDoente infectado, int[][] mapcomp) {
        boolean vacina = false;
        int comparacao = mapcomp[infectado.getY()][infectado.getX()];
        
        if(infectado.getCor() == 8){
            infectado.mover();
            vacina = true;
        }
        //Doentes em contato com Hospital
        else if (infectado.getCor() == 6 && comparacao == hospitais.get(0).getCor() || comparacao == hospitais.get(0).getCor() + 1) {

            saudaveis.add(new PessoaSaudavel(infectado.getX(), infectado.getY(), 5));
            saudaveis.get(saudaveis.size() - 1).mover();

            world[saudaveis.get(saudaveis.size() - 1).getY()][saudaveis.get(saudaveis.size() - 1).getX()] = saudaveis.get(saudaveis.size() - 1).getCor();
            infectados.remove(contador);
            vacina = true;
        }
        else {
            infectado.mover();
            vacina = false;
        }
        return vacina;
    }
    
    /**
     * 
     * @param contador Representa o índice da Pessoa Saudável no ArrayList PessoaSaudavel.
     * @param sadio Instância do Arraylist PessoaSaudavel, o qual será verificado.
     * @param mapcomp Mapa usado para comparação e checagem da colisão com o
     * Hospital.
     * @return vacina - Booleano que retorna se houve cura da PessoaSaudavel
     * ou não. 
     */
    public boolean verificaColisaoHospitalSaudavel(int contador, PessoaSaudavel sadio, int[][] mapcomp){
        boolean vacina = false;
        int comparacao = mapcomp[sadio.getY()][sadio.getX()];
        
        if(sadio.getCor() == 8){
            sadio.mover();
            vacina = true;
        }
        //Vacinados - Saudaveis em contato com o hospital
        else if (sadio.getCor() == 5 && comparacao == hospitais.get(0).getCor() || comparacao == hospitais.get(0).getCor() + 1){

            saudaveis.add(new PessoaSaudavel(true, sadio.getX(), sadio.getY(), 7));
            saudaveis.get(saudaveis.size() - 1).mover();

            world[saudaveis.get(saudaveis.size() - 1).getY()][saudaveis.get(saudaveis.size() - 1).getX()] = saudaveis.get(saudaveis.size() - 1).getCor();
            saudaveis.remove(contador);
            vacina = true;
        }
        else{
            sadio.mover();
            vacina = false;
        }
        return vacina;
    }
    
    /**
     * @param mapcomp Mapa usado para comparação e checagem da colisão com o
     * Hospital.
     */
    public void verificaPessoasInfectadas(int[][] mapcomp) {
        for (int i = 0; i < infectados.size(); i++) {
            world[infectados.get(i).getY()][infectados.get(i).getX()] = mapcomp[infectados.get(i).getY()][infectados.get(i).getX()];
            boolean morte = contTime(i, infectados.get(i), (int) temp);

            if (infectados.isEmpty() == false && morte == false) {
                boolean cura = verificaColisaoHospital(i, infectados.get(i), mapcomp);

                if (cura == false) {
                    world[infectados.get(i).getY()][infectados.get(i).getX()] = infectados.get(i).getCor();
                }
            }
        }
    }
    
    /**
     * @param mapcomp Mapa usado para comparação e checagem da colisão com o
     * Hospital. 
     */
    public void verificaPessoasVacinadas(int[][] mapcomp) {
        for (int i = 0; i < saudaveis.size(); i++) {
            world[saudaveis.get(i).getY()][saudaveis.get(i).getX()] = mapcomp[saudaveis.get(i).getY()][saudaveis.get(i).getX()];

            if (saudaveis.isEmpty() == false) {
                boolean cura = verificaColisaoHospitalSaudavel(i, saudaveis.get(i), mapcomp);

                if (cura == false) {
                    world[saudaveis.get(i).getY()][saudaveis.get(i).getX()] = saudaveis.get(i).getCor();
                }
            }
        }
    }
    
    /**
     * @param mapcomp Mapa usado para comparação e checagem da colisão com o
     * Hospital. 
     */
    public void verificaPessoasSaudaveis(int[][] mapcomp) {
        for (int i = 0; i < saudaveis.size(); i++) {
            world[saudaveis.get(i).getY()][saudaveis.get(i).getX()] = mapcomp[saudaveis.get(i).getY()][saudaveis.get(i).getX()];
            boolean contaminacao = verificaColisao(i, saudaveis.get(i));

            if (saudaveis.isEmpty() == false && contaminacao == false) {
                world[saudaveis.get(i).getY()][saudaveis.get(i).getX()] = saudaveis.get(i).getCor();
            }
        }
    }
    
    /**
     * @param mapcomp Mapa usado para comparação e checagem da colisão com o
     * Hospital. 
     */
    public void verificaPessoasVacinadasInfectadas(int[][] mapcomp) {
        for (int i = 0; i < saudaveis.size(); i++) {
            world[saudaveis.get(i).getY()][saudaveis.get(i).getX()] = mapcomp[saudaveis.get(i).getY()][saudaveis.get(i).getX()];
            boolean morte = contTimeVacinado(i, saudaveis.get(i), (int) temp);

            if (saudaveis.isEmpty() == false && morte == false) {
                boolean contaminacao = verificaColisaoVacinada(i, saudaveis.get(i));
                if (contaminacao == false){
                    world[saudaveis.get(i).getY()][saudaveis.get(i).getX()] = saudaveis.get(i).getCor();
                }  
            }
        }
    }
    
    /**
     * @param contador Representa o índice do Infectado no ArrayList PessoaDoente.
     * @param infectado Instância do Arraylist PessoaDoente, o qual será verificado.
     * @param tempoSimulacao Tempo atual do programa.
     * @return std - Booleano que retorna se a pessoa morreu ou não.
     */
    public boolean contTime(int contador, PessoaDoente infectado, int tempoSimulacao) {
        boolean std = false;
        if (tempoSimulacao - infectado.covid.getContaminatedTime() >= 30) {
            infectados.remove(contador);
            std = true;
        } else {
            std = false;
        }
        return std;
    }
    
    /**
     * @param contador Representa o índice da Pessoa Saudável no ArrayList PessoaSaudavel.
     * @param sadio Instância do Arraylist PessoaSaudavel, o qual será verificado.
     * @param tempoSimulacao Tempo atual do programa.
     * @return std - Booleano que retorna se a pessoa vacinada está com o vírus
     * a mais de 30 segundos ou não.
     */
    public boolean contTimeVacinado(int contador, PessoaSaudavel sadio, int tempoSimulacao) {
        boolean std = false;
        
        if (sadio.getCor() == 8 && tempoSimulacao - sadio.getTime() >= 30) {
            saudaveis.add(new PessoaSaudavel(true,saudaveis.get(contador).getX(), saudaveis.get(contador).getY(), 7));
            saudaveis.remove(contador);
            std = true;  
        } else {
            std = false;
        }
        return std;
    }
    
    /**
     * @return mapcomp - Mapa usado para comparação das posições.
     */
    public int[][] mapaDeComparacao() {
        int[][] mapcomp = new int[world.length][];
        for (int i = 0; i < world.length; i++) {
            mapcomp[i] = world[i].clone();
        }
        return mapcomp;
    }
    
    public void bigBang(){
        Scanner entrada = new Scanner(System.in);
        System.out.println("\n+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-");
        System.out.print("   ___                                       _                _           \n" +
                         "  | _ )    ___    _ __      o O O  __ __    (_)    _ _     __| |    ___   \n" +
                         "  | _ \\   / -_)  | '  \\    o       \\ V /    | |   | ' \\   / _` |   / _ \\  \n" +
                         "  |___/   \\___|  |_|_|_|  JP__[O]  _\\_/_   _|_|_  |_||_|  \\__,_|   \\___/  \n" +
                         "_|\"\"\"\"\"|_|\"\"\"\"\"|_|\"\"\"\"\"| {======|_|\"\"\"\"\"|_|\"\"\"\"\"|_|\"\"\"\"\"|_|\"\"\"\"\"|_|\"\"\"\"\"| \n" +
                         "\"`-0-0-'\"`-0-0-'\"`-0-0-'./o--000'\"`-0-0-'\"`-0-0-'\"`-0-0-'\"`-0-0-'\"`-0-0-' " + "\n");
        System.out.println("\n+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-");
        System.out.print("\n[" + verde + "]" + " Digite a quantidade de pessoas saudáveis: ");
        int pessoasSaudaveis = entrada.nextInt();
        System.out.print("\n["+ amarelo + "]" + " Digite a quantidade de pessoas doentes: ");
        int pessoasInfectadas = entrada.nextInt();
        System.out.println("\n+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-");

        criaHospital(hospitais, 3);
        hospitais(world);
        criaSaudavel(saudaveis, pessoasSaudaveis);
        criaInfectado(infectados, pessoasInfectadas);

        int[][] mapcomp = mapaDeComparacao();
        Timer cronometro = new Timer();
        TimerTask newTarefa = new TimerTask() {
                @Override
                public void run() {
                    if (infectados.isEmpty()) {
                        System.out.println("\n[+] Não há mais pessoas doentes !!!");
                        System.out.println("\n[+] A vacinação foi efetiva !!!");
                        cronometro.cancel();
                    }else if (saudaveis.isEmpty()) {
                        System.out.println("\n[+] Não há mais pessoas saudavéis !!!");
                        System.out.println("\n[+] Lockdown total recomendado !!!");
                        cronometro.cancel();
                    }else if (infectados.size() + saudaveis.size() == 0) {
                        System.out.println("\n[+] Não há mais pessoas vivas !!!");
                        System.out.println("\n[+] A \"gripinha\" matou todo mundo !!!");
                        cronometro.cancel();
                    }
                    else{
                        temp += 1.0;
                        verificaPessoasInfectadas(mapcomp);
                        verificaPessoasVacinadas(mapcomp);
                        verificaPessoasSaudaveis(mapcomp);
                        verificaPessoasVacinadasInfectadas(mapcomp);
                        System.out.println("\n+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-");
                        System.out.println("   ______                             _____ _                 __      __            \n" +
                                           "  / ____/___  _________  ____  ____ _/ ___/(_)___ ___  __  __/ /___ _/ /_____  _____\n" +
                                           " / /   / __ \\/ ___/ __ \\/ __ \\/ __ `/\\__ \\/ / __ `__ \\/ / / / / __ `/ __/ __ \\/ ___/\n" +
                                           "/ /___/ /_/ / /  / /_/ / / / / /_/ /___/ / / / / / / / /_/ / / /_/ / /_/ /_/ / /    \n" +
                                           "\\____/\\____/_/   \\____/_/ /_/\\__,_//____/_/_/ /_/ /_/\\__,_/_/\\__,_/\\__/\\____/_/     \n" +
                                           "                                                                                    \n" +
                                           "                     |___________________________________\n" +
                                           "               |-----|- - -|''''|''''|''''|''''|''''|'##\\|__\n" +
                                           "               |- -  |  cc 6    5    4    3    2    1 ### __]==--------------\n" +
                                           "               |-----|________________________________##/|\n" +
                                           "                     |\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"`");
                        System.out.println("+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-");
                        System.out.println("\n[+] Tempo de simulação: " + (int) temp + "                      " + " [+] Total de pessoas: " + (saudaveis.size() + infectados.size()));
                        System.out.println("\n[" + verde + "]" + " Pessoas Saudáveis sem vacina: " + saudaveis.size() +  "           " + " ["+ amarelo + "]" + " Pessoas Doentes: " + infectados.size());
                        System.out.println("\n[" + ciano + "]" + " Pessoas Saudáveis Vacinadas e sem vírus" + "    " + " ["+ magenta + "]" + " Pessoas Saudáveis Vacinadas mas com vírus\n");

                        for (int[] mundo : world) {
                            for (int j = 0; j < world[0].length; j++) {
                               switch (mundo[j]) {
                                    case 1:
                                        System.out.print(vermelho);
                                        break;
                                    case 3:
                                        System.out.print(branco);
                                        break;
                                    case 5:
                                        System.out.print(verde);
                                        break;
                                    case 6:
                                        System.out.print(amarelo);
                                        break;
                                    case 7:
                                        System.out.print(ciano);
                                        break;
                                    case 8:
                                        System.out.print(magenta);
                                        break;
                                    default:
                                        System.out.print(" ");
                                        break;   
                                }
                            }System.out.println();
                        }
                    }
                }
            };
            cronometro.schedule(newTarefa, 0, 500);
        }
    }
    