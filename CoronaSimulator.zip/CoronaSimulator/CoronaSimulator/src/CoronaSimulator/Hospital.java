package CoronaSimulator;

/**
 * Classe Hospital: Armazena os métodos e construtores da Classe Hospital.
 * Compõe a classe Mundo.
 * @author João Pedro Rosa Cezarino (22.120.021 - 5)
 */

public class Hospital {
    private int cor;

    public Hospital() {
    }
    
    /**
     * @param cor Número que representa a cor do objeto no mundo.
     */
    public Hospital(int cor) {
        this.cor = cor;
    }
    
    /**
     * @return int Número que representa a cor do objeto no mundo.
     */
    public int getCor() {
        return cor;
    }

    public void setCor(int cor) {
        this.cor = cor;
    }
}
